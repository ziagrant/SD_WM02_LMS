// ─── isLoggedIn ───────────────────────────────────────────────────────────────
// Blocks any request where no valid session exists.
// Attach to any route that requires a logged-in user.

function isLoggedIn(req, res, next) {
  if (!req.session || !req.session.user) {
    return res.status(401).json({ error: 'Not authenticated. Please log in.' });
  }
  next();
}

// ─── isHR ─────────────────────────────────────────────────────────────────────
// Blocks employees from accessing HR-only routes.
// Always stack after isLoggedIn.
// Usage:  router.get('/route', isLoggedIn, isHR, handler)

function isHR(req, res, next) {
  if (req.session.user.role !== 'hr') {
    return res.status(403).json({ error: 'Access denied. HR only.' });
  }
  next();
}

// ─── isApproved ───────────────────────────────────────────────────────────────
// Prevents employees whose accounts are still pending/rejected
// from submitting leave requests or accessing their dashboard data.

function isApproved(req, res, next) {
  if (req.session.user.role === 'hr') return next(); // HR always approved
  if (req.session.user.status !== 'approved') {
    return res.status(403).json({
      error: 'Your account is pending HR approval. You cannot perform this action yet.'
    });
  }
  next();
}

module.exports = { isLoggedIn, isHR, isApproved };
