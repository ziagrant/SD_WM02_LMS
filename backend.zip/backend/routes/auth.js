const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const db = require('../db');
const { isLoggedIn } = require('../middleware/auth');

// ─── POST /api/auth/register ──────────────────────────────────────────────────
// Called by signup.html
// Creates a new employee account with status = 'pending'
// HR must approve before the employee can log in and apply for leave.

router.post('/register', async (req, res) => {
  const { firstName, lastName, employeeNumber, email, department, password, confirmPassword } = req.body;

  // Basic validation
  if (!firstName || !lastName || !employeeNumber || !email || !department || !password) {
    return res.status(400).json({ error: 'All fields are required.' });
  }

  // Password match check
  if (password !== confirmPassword) {
    return res.status(400).json({ error: 'Passwords do not match.' });
  }

  // Password strength: must have uppercase, lowercase, and a number
  const strongPassword = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).{6,}$/;
  if (!strongPassword.test(password)) {
    return res.status(400).json({
      error: 'Password must contain uppercase, lowercase letters, and a number.'
    });
  }

  try {
    // Check if email or employee number already exists
    const [existing] = await db.promise().query(
      'SELECT id FROM users WHERE email = ? OR employee_number = ?',
      [email, employeeNumber]
    );

    if (existing.length > 0) {
      return res.status(409).json({ error: 'Email or employee number already registered.' });
    }

    // Hash the password before storing
    const hashedPassword = await bcrypt.hash(password, 10);

    await db.promise().query(
      `INSERT INTO users (first_name, last_name, employee_number, email, department, password, role, status)
       VALUES (?, ?, ?, ?, ?, ?, 'employee', 'pending')`,
      [firstName, lastName, employeeNumber, email, department, hashedPassword]
    );

    res.status(201).json({
      message: 'Account created. Please wait for HR approval before logging in.'
    });

  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ error: 'Server error during registration.' });
  }
});

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
// Used by both employee-login.html and hr-login.html
// The frontend sends a `role` field so the server can redirect accordingly.

router.post('/login', async (req, res) => {
  const { email, password, role } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  try {
    const [rows] = await db.promise().query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );

    if (rows.length === 0) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    const user = rows[0];

    // Verify password against hash
    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ error: 'Invalid email or password.' });
    }

    // Role check — employee cannot log in via the HR login page and vice versa
    if (role && user.role !== role) {
      return res.status(403).json({ error: `This account is not registered as ${role}.` });
    }

    // Employees must be approved before they can log in
    if (user.role === 'employee' && user.status !== 'approved') {
      return res.status(403).json({
        error: 'Your account is still pending HR approval.'
      });
    }

    // Save user info to session (never save the password)
    req.session.user = {
      id: user.id,
      firstName: user.first_name,
      lastName: user.last_name,
      email: user.email,
      role: user.role,
      department: user.department,
      employeeNumber: user.employee_number,
      status: user.status
    };

    res.json({
      message: 'Login successful.',
      user: req.session.user
    });

  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error during login.' });
  }
});

// ─── POST /api/auth/logout ────────────────────────────────────────────────────
// Destroys the session. Called when clicking Logout in the sidebar.

router.post('/logout', (req, res) => {
  req.session.destroy((err) => {
    if (err) {
      return res.status(500).json({ error: 'Could not log out.' });
    }
    res.clearCookie('connect.sid');
    res.json({ message: 'Logged out successfully.' });
  });
});

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
// The frontend calls this on page load to check if the user is still logged in.
// If not, it redirects to the login page.

router.get('/me', isLoggedIn, (req, res) => {
  res.json({ user: req.session.user });
});

module.exports = router;
